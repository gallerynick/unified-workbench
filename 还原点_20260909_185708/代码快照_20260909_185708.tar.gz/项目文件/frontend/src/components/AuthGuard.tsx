import { useState, useEffect } from 'react';
import { Navigate, Outlet, useNavigate } from 'react-router-dom';
import { Result, Button } from 'antd';
import { LockOutlined } from '@ant-design/icons';
import { isAuthenticated, isAdmin, clearTokens, tryRefreshAuth } from '@/utils/auth';
import { isMaintenanceModeEnabled } from '@/pages/settings/SiteSettings';

export default function AuthGuard() {
  const navigate = useNavigate();
  const [setupStatus, setSetupStatus] = useState<{ loading: boolean; complete: boolean | null }>({
    loading: true,
    complete: null,
  });
  const [authChecked, setAuthChecked] = useState<boolean>(false);
  const [maintenance, setMaintenance] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/v1/auth/setup-status')
      .then((r) => r.json())
      .then((json) => setSetupStatus({
        loading: false,
        complete: json?.data?.complete === true,
      }))
      .catch(() => setSetupStatus({ loading: false, complete: null }));
  }, []);

  useEffect(() => {
    let cancelled = false;
    const checkAuth = async () => {
      if (isAuthenticated()) {
        if (!cancelled) setAuthChecked(true);
        return;
      }
      await tryRefreshAuth();
      if (!cancelled) setAuthChecked(true);
    };
    const checkMaintenance = async () => {
      const enabled = await isMaintenanceModeEnabled();
      if (!cancelled) setMaintenance(enabled);
    };
    checkAuth();
    checkMaintenance();
    return () => {
      cancelled = true;
    };
  }, []);

  // 加载中
  if (setupStatus.loading || !authChecked) return null;

  // 系统未初始化 → 欢迎页（不需要登录）
  if (setupStatus.complete === false) {
    return <Navigate to="/welcome" replace />;
  }

  // 已初始化但未登录 → 登录页
  if (!isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }

  // 维护模式且非管理员 → 403 禁止访问
  if (maintenance && !isAdmin()) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: 'var(--canvas)',
      }}>
        <Result
          status="403"
          title={<span style={{ color: 'var(--ink)' }}>访问被拒绝</span>}
          subTitle={<span style={{ color: 'var(--text-secondary)' }}>系统当前处于维护模式，仅管理员可以访问。</span>}
          icon={<LockOutlined style={{ fontSize: 72, color: 'var(--color-info)' }} />}
          extra={
            <Button type="primary" onClick={() => { clearTokens(); navigate('/login', { replace: true }); }}>
              退出登录
            </Button>
          }
        />
      </div>
    );
  }

  return <Outlet />;
}