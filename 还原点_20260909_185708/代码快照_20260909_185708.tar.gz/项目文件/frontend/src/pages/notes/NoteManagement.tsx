import { useState, useEffect, useCallback, useMemo } from 'react';
import { Tree, Button, Typography, Modal, message, Space, Input, Tag, Tooltip, Segmented } from 'antd';
import { PlusOutlined, DeleteOutlined, PushpinOutlined, SearchOutlined, EditOutlined, FileOutlined, FolderOutlined, ApartmentOutlined, ShareAltOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import type { DataNode, TreeProps } from 'antd/es/tree';
import { listAllNotes, updateNote, deleteNote, moveNote } from '../../api/notes';
import type { Note } from '../../types/note';
import { useTheme } from '../../contexts/ThemeContext';
import GraphView from './GraphView';
import styles from './NoteManagement.module.css';
import NoteModal, { type NoteTreeSelectData } from './NoteModal';

const { Title, Paragraph, Text } = Typography;

interface TreeNodeData extends DataNode {
  note: Note;
  children?: TreeNodeData[];
}

function buildTree(notes: Note[]): TreeNodeData[] {
  const map = new Map<string, TreeNodeData>();
  const roots: TreeNodeData[] = [];

  // First pass: create all nodes
  notes.forEach((note) => {
    map.set(note.id, {
      key: note.id,
      note,
      title: '', // will be set in second pass
      children: [],
    });
  });

  // Second pass: build hierarchy
  notes.forEach((note) => {
    const node = map.get(note.id)!;
    if (note.parent_id && map.has(note.parent_id)) {
      const parent = map.get(note.parent_id)!;
      if (!parent.children) parent.children = [];
      parent.children.push(node);
    } else {
      roots.push(node);
    }
  });

  // Sort: pinned first, then by updated_at desc
  const sortNodes = (nodes: TreeNodeData[]) => {
    nodes.sort((a, b) => {
      if (a.note.is_pinned !== b.note.is_pinned) return a.note.is_pinned ? -1 : 1;
      return new Date(b.note.updated_at).getTime() - new Date(a.note.updated_at).getTime();
    });
    nodes.forEach((n) => { if (n.children) sortNodes(n.children); });
  };
  sortNodes(roots);

  return roots;
}

function renderTreeTitle(node: TreeNodeData, onPin: (note: Note) => void, onEdit: (note: Note) => void, onDelete: (note: Note) => void): React.ReactNode {
  const { note } = node;
  const hasChildren = node.children && node.children.length > 0;
  return (
    <span className={styles.treeNode}>
      <span className={styles.treeNodeTitle}>
        {hasChildren ? <FolderOutlined style={{ marginRight: "var(--spacing-xs)", color: 'var(--text-secondary)' }} /> : <FileOutlined style={{ marginRight: "var(--spacing-xs)", color: 'var(--text-secondary)' }} />}
        {note.is_pinned && <PushpinOutlined style={{ marginRight: "var(--spacing-xxs)", color: 'var(--color-warning)', fontSize: 'var(--text-body-xs-size)' }} />}
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{note.title}</span>
        {note.category && <Tag style={{ marginLeft: "var(--spacing-xs)", fontSize: 'var(--text-body-xs-size)', lineHeight: 'var(--text-caption-line)', padding: '0 6px', borderRadius: 'var(--rounded-chip)', color: 'var(--text-secondary)', background: 'transparent', border: 'var(--border-width-thin) solid var(--border-tertiary)' }}>{note.category}</Tag>}
      </span>
      <span className={styles.treeNodeActions}>
        <Tooltip title={note.is_pinned ? '取消置顶' : '置顶'}>
          <Button type="text" size="small" icon={<PushpinOutlined style={{ fontSize: 'var(--text-body-xs-size)' }} />} aria-label="切换置顶" onClick={(e) => { e.stopPropagation(); onPin(note); }} />
        </Tooltip>
        <Tooltip title="编辑">
          <Button type="text" size="small" icon={<EditOutlined style={{ fontSize: 'var(--text-body-xs-size)' }} />} aria-label="编辑" onClick={(e) => { e.stopPropagation(); onEdit(note); }} />
        </Tooltip>
        <Tooltip title="删除">
          <Button type="text" size="small" danger icon={<DeleteOutlined style={{ fontSize: 'var(--text-body-xs-size)' }} />} aria-label="删除" onClick={(e) => { e.stopPropagation(); onDelete(note); }} />
        </Tooltip>
      </span>
    </span>
  );
}

function filterTree(nodes: TreeNodeData[], search: string): TreeNodeData[] {
  const lower = search.toLowerCase();
  const result: TreeNodeData[] = [];
  nodes.forEach((node) => {
    const matchedChildren = node.children ? filterTree(node.children, search) : [];
    const selfMatch = node.note.title.toLowerCase().includes(lower) ||
      (node.note.content?.toLowerCase().includes(lower) ?? false) ||
      (node.note.category?.toLowerCase().includes(lower) ?? false);
    if (selfMatch || matchedChildren.length > 0) {
      const newNode: TreeNodeData = { ...node };
      if (matchedChildren.length > 0) newNode.children = matchedChildren;
      else delete (newNode as TreeNodeData & { children?: unknown }).children;
      result.push(newNode);
    }
  });
  return result;
}

function collectAllNodes(nodes: TreeNodeData[]): TreeNodeData[] {
  const result: TreeNodeData[] = [];
  nodes.forEach((n) => {
    result.push(n);
    if (n.children) result.push(...collectAllNodes(n.children));
  });
  return result;
}

export default function NoteManagement() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'tree' | 'graph'>('tree');
  const { isDark } = useTheme();
  const [modalVisible, setModalVisible] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [permissionVisible, setPermissionVisible] = useState(false);

  const fetchNotes = useCallback(async () => {
    setLoading(true);
    try {
      const res = await listAllNotes();
      if (res.code === 0) setNotes(res.data.items);
    } catch { message.error('获取笔记列表失败'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchNotes(); }, [fetchNotes]);

  const openCreateModal = useCallback(() => {
    setEditingNote(null);
    setModalVisible(true);
  }, []);

  const openEditModal = useCallback((note: Note) => {
    setEditingNote(note);
    setSelectedKeys([note.id]);
    setModalVisible(true);
  }, []);

  const handleDelete = useCallback((note: Note) => {
    const hasChildren = notes.some((n) => n.parent_id === note.id);
    Modal.confirm({
      title: '确认删除',
      content: hasChildren
        ? `确定要删除笔记「${note.title}」吗？其子笔记将变为根笔记。`
        : `确定要删除笔记「${note.title}」吗？`,
      okText: '删除', okButtonProps: { danger: true }, cancelText: '取消',
      onOk: async () => {
        try {
          const res = await deleteNote(note.id);
          if (res.code === 0) { message.success('笔记已删除'); fetchNotes(); }
        } catch { message.error('删除失败'); }
      },
    });
  }, [notes, fetchNotes]);

  const handleTogglePin = useCallback(async (note: Note) => {
    try {
      const res = await updateNote(note.id, { is_pinned: !note.is_pinned });
      if (res.code === 0) { message.success(note.is_pinned ? '已取消置顶' : '已置顶'); fetchNotes(); }
    } catch { message.error('操作失败'); }
  }, [fetchNotes]);

  const treeData = useMemo(() => {
    const tree = buildTree(notes);
    const allNodes = collectAllNodes(tree);
    const pinHandler = (note: Note) => handleTogglePin(note);
    const editHandler = (note: Note) => openEditModal(note);
    const deleteHandler = (note: Note) => handleDelete(note);
    allNodes.forEach((n) => { n.title = renderTreeTitle(n, pinHandler, editHandler, deleteHandler); });
    return search ? filterTree(tree, search) : tree;
  }, [notes, search, handleTogglePin, openEditModal, handleDelete]);

  const treeSelectData = useMemo((): NoteTreeSelectData[] => {
    const tree = buildTree(notes);
    const buildSelectNodes = (nodes: TreeNodeData[]): NoteTreeSelectData[] =>
      nodes.map((n) => {
        const node: NoteTreeSelectData = {
          value: n.key as string,
          title: n.note.title,
          children: [],
          selectable: !editingNote || n.key !== editingNote.id,
        };
        if (n.children) node.children = buildSelectNodes(n.children);
        return node;
      });
    return buildSelectNodes(tree);
  }, [notes, editingNote]);

  const onDrop: TreeProps['onDrop'] = async (info) => {
    const dragKey = info.dragNode.key as string;
    let dropKey: string | null;
    if (info.dropToGap) {
      const dropNoteId = info.node.key as string;
      const dropNote = notes.find((n) => n.id === dropNoteId);
      dropKey = dropNote?.parent_id ?? null;
    } else {
      dropKey = info.node.key as string;
    }
    try {
      const res = await moveNote(dragKey, dropKey);
      if (res.code === 0) {
        message.success('移动成功');
        fetchNotes();
      } else {
        message.error('移动失败');
        fetchNotes();
      }
    } catch {
      message.error('移动失败: 不能移动到子节点下');
      fetchNotes();
    }
  };

  return (
    <div className={styles.container ?? ''}>
      <div className={styles.header ?? ''}>
        <Title level={4} className={styles.title ?? ''}>笔记知识库</Title>
        <Space>
          <Segmented
            value={viewMode}
            onChange={(value) => setViewMode(value as 'tree' | 'graph')}
            options={[
              { label: '树形浏览', value: 'tree', icon: <ApartmentOutlined /> },
              { label: '图形视图', value: 'graph', icon: <ShareAltOutlined /> },
            ]}
          />
          <Input placeholder="搜索笔记" prefix={<SearchOutlined style={{ color: 'var(--text-secondary)' }} />} allowClear value={search} onChange={(e) => setSearch(e.target.value)} variant="filled" className={styles.searchInput ?? ''} />
          <Button type="primary" icon={<PlusOutlined />} onClick={openCreateModal}>新建笔记</Button>
          <Tooltip title="权限说明">
            <Button
              type="text"
              size="small"
              icon={<QuestionCircleOutlined />}
              onClick={() => setPermissionVisible(true)}
            />
          </Tooltip>
        </Space>
      </div>

      {notes.length === 0 && !loading ? (
        <div className={styles.emptyState}>
          <FileOutlined style={{ fontSize: 40, marginBottom: "var(--spacing-sm)", color: 'var(--text-secondary)' }} />
          <div>还没有笔记，点击「新建笔记」创建一个吧</div>
        </div>
      ) : viewMode === 'tree' ? (
        <Tree
          treeData={treeData}
          draggable
          blockNode
          showLine={{ showLeafIcon: false }}
          onDrop={onDrop}
          selectedKeys={selectedKeys}
          className={styles.noteTree ?? ''}
        />
      ) : (
        <div style={{ height: 'calc(100vh - 220px)', minHeight: 400 }}>
          <GraphView
            notes={notes}
            onNodeClick={openEditModal}
            isDark={isDark}
            search={search}
          />
        </div>
      )}

      <NoteModal
        open={modalVisible}
        editingNote={editingNote}
        treeData={treeSelectData}
        onClose={() => { setModalVisible(false); setSelectedKeys([]); }}
        onSaved={fetchNotes}
      />

      <Modal
        title="权限说明"
        open={permissionVisible}
        width={560}
        footer={null}
        onCancel={() => setPermissionVisible(false)}
      >
        <div className={styles.permissionContent ?? ''}>
          <Title level={5}>创建者权限</Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>创建者拥有笔记的完整管理权限，可以编辑内容、移动笔记、置顶、删除和设置可见范围。</Paragraph>
          <Title level={5}>成员/指定用户权限</Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>可见范围内的成员可以查看笔记；被指定的用户只能查看被授权给自己的笔记。</Paragraph>
          <Title level={5}>可见范围</Title>
          <ul className={styles.permissionList ?? ''}>
            <li>
              <Text type="secondary" style={{ fontSize: 'var(--text-body-xs-size)' }}>
                公开：所有成员都可以查看该笔记
              </Text>
            </li>
            <li>
              <Text type="secondary" style={{ fontSize: 'var(--text-body-xs-size)' }}>
                私有：仅创建者和被授权成员可以查看
              </Text>
            </li>
            <li>
              <Text type="secondary" style={{ fontSize: 'var(--text-body-xs-size)' }}>
                指定用户：仅被指定的用户可以看到该笔记
              </Text>
            </li>
          </ul>
          <Title level={5}>管理员</Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>系统管理员可以管理自己创建以及被指定给自己的笔记。</Paragraph>
          <Title level={5}>创建权限</Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>所有成员都可以创建笔记，创建时需设定可见范围。</Paragraph>
        </div>
      </Modal>
    </div>
  );
}
