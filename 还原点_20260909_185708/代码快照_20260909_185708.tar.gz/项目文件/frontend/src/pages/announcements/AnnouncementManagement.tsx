import { useState, useEffect, useCallback } from 'react';
import {
  Button,
  Typography,
  Modal,
  message,
  Tag,
  Tooltip,
  Card,
  Tabs,
  Space,
  Popconfirm,
  Empty,
  Pagination,
} from 'antd';
import {
  PlusOutlined,
  DeleteOutlined,
  PushpinOutlined,
  EditOutlined,
  QuestionCircleOutlined,
} from '@ant-design/icons';
import { listAnnouncements, deleteAnnouncement } from '../../api/announcements';
import type { Announcement } from '../../types/announcement';
import { getUserId, isAdmin } from '../../utils/auth';
import AnnouncementModal from './AnnouncementModal';
import styles from './AnnouncementManagement.module.css';

const { Title, Text, Paragraph } = Typography;

type TabKey = 'all' | 'mine';

export default function AnnouncementManagement() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(12);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<TabKey>('all');

  // ── 弹窗状态（共用组件 AnnouncementModal） ──
  const [announcementModalOpen, setAnnouncementModalOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [permissionVisible, setPermissionVisible] = useState(false);

  const currentUserId = getUserId();
  const userIsAdmin = isAdmin();

  const fetchAnnouncements = useCallback(async () => {
    setLoading(true);
    try {
      const params: { page: number; page_size: number; owner_id?: string } = {
        page,
        page_size: pageSize,
      };
      if (activeTab === 'mine' && currentUserId) {
        params.owner_id = currentUserId;
      }
      const res = await listAnnouncements(params);
      if (res.code === 0) {
        setAnnouncements(res.data.items);
        setTotal(res.data.total);
      }
    } catch {
      message.error('获取公告列表失败');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, activeTab, currentUserId]);

  useEffect(() => {
    fetchAnnouncements();
  }, [fetchAnnouncements]);

  const handleTabChange = (key: string) => {
    setActiveTab(key as TabKey);
    setPage(1);
  };

  // ── 打开新建/编辑（弹窗共用 AnnouncementModal） ──
  const handleCreate = () => {
    setEditingAnnouncement(null);
    setAnnouncementModalOpen(true);
  };

  const handleEdit = (a: Announcement) => {
    setEditingAnnouncement(a);
    setAnnouncementModalOpen(true);
  };

  const handleDelete = async (a: Announcement) => {
    try {
      const res = await deleteAnnouncement(a.id);
      if (res.code === 0) {
        message.success('公告已删除');
        fetchAnnouncements();
      }
    } catch {
      message.error('删除失败');
    }
  };

  const canManage = (item: Announcement): boolean => {
    return item.owner_id === currentUserId || userIsAdmin;
  };

  const tabItems = [
    { key: 'all', label: '全部' },
    { key: 'mine', label: '我创建的' },
  ];

  return (
    <div className={styles.container ?? ''}>
      <div className={styles.header ?? ''}>
        <Title level={4} className={styles.title ?? ''}>
          公告通知
        </Title>
        <Space>
          <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
            发布公告
          </Button>
          <Tooltip title="权限说明">
            <Button
              type="text"
              size="small"
              icon={<QuestionCircleOutlined />}
              onClick={() => setPermissionVisible(true)}
            />
          </Tooltip>
        </Space>
      </div>

      <Tabs activeKey={activeTab} items={tabItems} onChange={handleTabChange} className={styles.tabs ?? ''} />

      {announcements.length === 0 && !loading ? (
        <Empty description="暂无公告" className={styles.empty ?? ''} />
      ) : (
        <>
          <div className={styles.cardGrid}>
            {announcements.map((item) => (
                <Card
                key={item.id}
                className={styles.card ?? ''}
                loading={loading}
                title={
                  <div className={styles.cardTitle}>
                    {item.is_pinned && (
                      <Tooltip title="置顶">
                        <PushpinOutlined className={styles.pinIcon} />
                      </Tooltip>
                    )}
                    <Text ellipsis className={styles.titleText ?? ''}>
                      {item.title}
                    </Text>
                  </div>
                }
                extra={
                  <Tag color={item.is_published ? 'green' : 'default'}>
                    {item.is_published ? '已发布' : '草稿'}
                  </Tag>
                }
              >
                <div className={styles.cardContent}>
                  <Text type="secondary" className={styles.contentPreview ?? ''}>
                    {item.content.length > 120 ? `${item.content.slice(0, 120)}...` : item.content}
                  </Text>
                  <Text type="secondary" className={styles.meta ?? ''}>
                    {new Date(item.created_at).toLocaleString('zh-CN')}
                  </Text>
                </div>
                {canManage(item) && (
                  <div className={styles.cardActions}>
                    <Space>
                      <Tooltip title="编辑">
                        <Button
                          type="link"
                          size="small"
                          icon={<EditOutlined />}
                          onClick={() => handleEdit(item)}
                        >
                          编辑
                        </Button>
                      </Tooltip>
                      <Popconfirm
                        title="确认删除"
                        description={`确定要删除公告「${item.title}」吗？`}
                        okText="删除"
                        cancelText="取消"
                        okButtonProps={{ danger: true }}
                        onConfirm={() => handleDelete(item)}
                      >
                        <Tooltip title="删除">
                          <Button type="link" size="small" danger icon={<DeleteOutlined />}>
                            删除
                          </Button>
                        </Tooltip>
                      </Popconfirm>
                    </Space>
                  </div>
                )}
              </Card>
            ))}
          </div>
          <div className={styles.pagination}>
            <Pagination
              current={page}
              pageSize={pageSize}
              total={total}
              showSizeChanger
              showQuickJumper
              pageSizeOptions={[10, 12, 20, 50]}
              showTotal={(t) => `共 ${t} 条`}
              onChange={(p, ps) => { setPage(p); if (ps) setPageSize(ps); }}
            />
          </div>
        </>
      )}

      {/* 发布/编辑 公告（共用组件 AnnouncementModal） */}
      <AnnouncementModal
        open={announcementModalOpen}
        editingAnnouncement={editingAnnouncement}
        onClose={() => setAnnouncementModalOpen(false)}
        onSaved={() => void fetchAnnouncements()}
      />

      {/* 权限说明弹窗 */}
      <Modal
        title="权限说明"
        open={permissionVisible}
        width={560}
        footer={null}
        onCancel={() => setPermissionVisible(false)}
        destroyOnClose
      >
        <div className={styles.permissionContent ?? ''}>
          <Title level={5}>
            发布权限
          </Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>只有管理员可以发布公告通知，所有成员都可以查看已发布的公告。</Paragraph>
          <Title level={5}>
            发布状态
          </Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>已发布的公告对所有成员可见；草稿状态的公告仅创建者和管理员可见。</Paragraph>
          <Title level={5}>
            编辑与删除
          </Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>公告创建者和管理员可以编辑、删除自己创建的公告。</Paragraph>
          <Title level={5}>
            置顶
          </Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>管理员可以将重要公告置顶显示，置顶公告优先展示在所有成员首页。</Paragraph>
          <Title level={5}>
            管理员
          </Title>
          <Paragraph style={{ fontSize: 'var(--text-body-sm-size)' }}>系统管理员可以发布、编辑和删除所有公告。</Paragraph>
        </div>
      </Modal>
    </div>
  );
}
