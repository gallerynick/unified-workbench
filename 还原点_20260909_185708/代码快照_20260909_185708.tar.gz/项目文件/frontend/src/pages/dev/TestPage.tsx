import {
  AppstoreOutlined,
  CloudOutlined,
  FireOutlined,
  ThunderboltOutlined,
  ThunderboltTwoTone,
  UnorderedListOutlined,
  SyncOutlined,
} from '@ant-design/icons';
import { Button, List, Result, Space, Typography } from 'antd';
import type { ReactNode } from 'react';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { isDebugModeEnabled } from '@/pages/settings/SiteSettings';
import BackgroundAnimationSection from './TestPageBackground';
import SmokeBandAnimationSection from './TestPageSmokeBand';
import HapticsTestSection from './TestPageHaptics';
import ConvergenceAnimationSection from './TestPageConvergence';
import AftermathAnimationSection from './TestPageAftermath';
import styles from './TestPage.module.css';

const { Title, Paragraph, Text } = Typography;

interface Section {
  key: string;
  label: string;
  icon: ReactNode;
  description: string;
  render: () => ReactNode;
}

function ExampleSection() {
  return (
    <Space direction="vertical" size="large" style={{ width: '100%' }}>
      <div>
        <Text strong>这是一个示例分区</Text>
        <Paragraph type="secondary" style={{ marginTop: 8, marginBottom: 0 }}>
          新增分区：在下方 SECTIONS 数组中追加一个条目，填写 key、label、icon、description 与 render，
          即可在索引页中看到新分区。框架本身不需要改动。
        </Paragraph>
      </div>
      <Space wrap>
        <Button type="primary">主要按钮</Button>
        <Button>默认按钮</Button>
        <Button danger>危险按钮</Button>
      </Space>
    </Space>
  );
}

const SECTIONS: Section[] = [
  {
    key: 'example',
    label: '示例分区',
    icon: <AppstoreOutlined />,
    description: '按钮与基础组件展示',
    render: () => <ExampleSection />,
  },
  {
    key: 'animation-bg',
    label: 'Phase 1 — 网格凹面背景',
    icon: <CloudOutlined />,
    description: 'WebGL 凹面网格背景（scale=1/(1+k·r²) 凹面公式，k=2.0，vignette 边缘暗化）',
    render: () => <BackgroundAnimationSection />,
  },
  {
    key: 'animation-smoke',
    label: 'Phase 2 — 丝绸流粒子',
    icon: <FireOutlined />,
    description: '65 流 × 350 粒子 = 22750，平行水平丝绸状粒子流，三层亮度+密度调制+闪烁',
    render: () => <SmokeBandAnimationSection />,
  },
  {
    key: 'animation-convergence',
    label: 'Phase 3 — 粒子汇聚文字',
    icon: <UnorderedListOutlined />,
    description: '丝绸流 → 汇聚 → 8000 粒子成型 UNIFIED WORKBENCH，多余粒子淡出，第一版亮度',
    render: () => <ConvergenceAnimationSection />,
  },
  {
    key: 'animation-aftermath',
    label: '欢迎动画 — 工作台欢迎动画',
    icon: <SyncOutlined />,
    description: '三层叠加整合动画（欢迎动画）',
    render: () => <AftermathAnimationSection />,
  },
  {
    key: 'background-animation',
    label: '背景互动动画',
    icon: <ThunderboltOutlined />,
    description: '粒子网络跟随鼠标互动',
    render: () => <BackgroundAnimationSection />,
  },
  {
    key: 'haptics-test',
    label: 'Mac 触控板震动测试',
    icon: <ThunderboltTwoTone />,
    description: 'navigator.vibrate / Force Touch / Web Haptics 可行性验证',
    render: () => <HapticsTestSection />,
  },
];

export default function TestPage() {
  const navigate = useNavigate();
  const { key } = useParams<{ key?: string }>();
  const [debugEnabled, setDebugEnabled] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const enabled = await isDebugModeEnabled();
      if (!cancelled) setDebugEnabled(enabled);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (debugEnabled === null) {
    return null; // 加载中
  }

  if (!debugEnabled) {
    return (
      <Result
        status="warning"
        title="调试模式未开启"
        subTitle="请在系统设置中启用调试模式后访问组件测试工作台"
        extra={
          <Button type="primary" onClick={() => navigate('/', { replace: true })}>
            返回工作台
          </Button>
        }
      />
    );
  }

  // ── 索引页 ──
  if (!key) {
    return (
      <div className={styles.page ?? ''}>
        <header className={styles.topbar ?? ''}>
            <Title level={4} style={{ margin: 0 }}>
              开发测试页
            </Title>
          <Button onClick={() => navigate('/', { replace: true })}>返回工作台</Button>
        </header>
        <div className={styles.indexContainer ?? ''}>
          <Paragraph type="secondary" style={{ marginBottom: 'var(--spacing-sm)' }}>
            以下列出所有测试分区，点击即可进入对应的测试页面。
          </Paragraph>
          <List
            size="small"
            dataSource={SECTIONS}
            renderItem={(s) => (
              <List.Item className={styles.indexItem ?? ''}>
                <a
                  href={`/dev/testpage/${s.key}`}
                  className={styles.indexLink ?? ''}
                >
                  <Space size={12} className={styles.indexContent ?? ''}>
                    <span className={styles.indexIcon}>{s.icon}</span>
                    <div className={styles.indexText}>
                      <Text strong>{s.label}</Text>
                      <Text type="secondary" style={{ fontSize: 'var(--text-caption-size)' }}>
                        {s.description}
                      </Text>
                    </div>
                  </Space>
                </a>
              </List.Item>
            )}
          />
        </div>
      </div>
    );
  }

  // ── 单项页 ──
  const section = SECTIONS.find((s) => s.key === key);
  if (!section) {
    return (
      <div className={styles.page ?? ''}>
        <header className={styles.topbar ?? ''}>
          <Title level={4} style={{ margin: 0 }}>
            测试工作台
          </Title>
          <Button onClick={() => navigate('/dev/testpage', { replace: true })}>返回索引</Button>
        </header>
        <Result
          status="404"
          title="未找到测试分区"
          subTitle={`没有找到 key 为 "${key}" 的测试分区`}
          extra={
            <Button type="primary" onClick={() => navigate('/dev/testpage', { replace: true })}>
              返回索引
            </Button>
          }
        />
      </div>
    );
  }

  return (
    <div className={styles.page ?? ''}>
      {section.render()}
    </div>
  );
}