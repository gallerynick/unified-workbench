import {
  ApartmentOutlined,
  AppstoreOutlined,
  BellOutlined,
  BgColorsOutlined,
  BookOutlined,
  CalendarOutlined,
  CheckSquareOutlined,
  ClockCircleOutlined,
  CloudServerOutlined,
  ContactsOutlined,
  DatabaseOutlined,
  DesktopOutlined,
  SafetyOutlined,
  FileOutlined,
  FileTextOutlined,
  FormOutlined,
  GlobalOutlined,
  HomeOutlined,
  KeyOutlined,
  LikeOutlined,
  LockOutlined,
  MenuFoldOutlined,
  MenuOutlined,
  MenuUnfoldOutlined,
  MoneyCollectOutlined,
  PauseCircleOutlined,
  ProjectOutlined,
  SettingOutlined,
  SkinOutlined,
  SoundOutlined,
  SwapOutlined,
  TagOutlined,
  TeamOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from '@ant-design/icons';
import type { MenuProps } from 'antd';
import {
  Avatar,
  Button,
  ConfigProvider,
  Drawer,
  Dropdown,
  Layout,
  Menu,
  Space,
  Tooltip,
  Typography,
} from 'antd';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import DebugModeOverlay from '../components/DebugModeOverlay';
import NotificationBell from '../components/NotificationBell';
import NotificationDrawer from '../components/NotificationDrawer';
import StatusIndicator from '../components/StatusIndicator';
import VotePopup from '../components/VotePopup';
import { getRouteTitle } from '../config/routeTitles';
import { useLockContext } from '../contexts/LockContext';
import { TagProvider } from '../contexts/TagContext';
import { useTheme, type ThemeMode } from '../contexts/ThemeContext';
import { useUser } from '../contexts/UserContext';
import { getUserPreferences } from '../api/user-preferences';
import { useResponsive } from '../hooks/useBreakpoint';
import { useCustomization } from '../hooks/useCustomization';
import { pauseIdleTimer, resumeIdleTimer, useIdleTimer } from '../hooks/useIdleTimer';
import { useStatusProbes } from '../hooks/useStatusProbes';
import { useWebSocket } from '../hooks/useWebSocket';
import { clearTokens, isAdmin } from '../utils/auth';
import styles from './MainLayout.module.css';

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

const ICON_MAP: Record<string, React.ReactNode> = {
  HomeOutlined: <HomeOutlined />,
  FileOutlined: <FileOutlined />,
  FileTextOutlined: <FileTextOutlined />,
  ProjectOutlined: <ProjectOutlined />,
  AppstoreOutlined: <AppstoreOutlined />,
  MoneyCollectOutlined: <MoneyCollectOutlined />,
  KeyOutlined: <KeyOutlined />,
  BellOutlined: <BellOutlined />,
  CheckSquareOutlined: <CheckSquareOutlined />,
  ContactsOutlined: <ContactsOutlined />,
  CalendarOutlined: <CalendarOutlined />,
  LikeOutlined: <LikeOutlined />,
  FormOutlined: <FormOutlined />,
  TeamOutlined: <TeamOutlined />,
  SoundOutlined: <SoundOutlined />,
  BookOutlined: <BookOutlined />,
  SettingOutlined: <SettingOutlined />,
  ApartmentOutlined: <ApartmentOutlined />,
  VideoCameraOutlined: <VideoCameraOutlined />,
  CloudServerOutlined: <CloudServerOutlined />,
  DatabaseOutlined: <DatabaseOutlined />,
};

interface SidebarItem {
  key: string;
  label: string;
  icon: string;
}

const SIDEBAR_ITEMS: SidebarItem[] = [
  { key: '/', label: '首页', icon: 'HomeOutlined' },
  { key: '/notifications', label: '通知中心', icon: 'BellOutlined' },
  { key: '/announcements', label: '公告通知', icon: 'SoundOutlined' },
  { key: '/tasks', label: '任务中心', icon: 'CheckSquareOutlined' },
  { key: '/members', label: '成员目录', icon: 'TeamOutlined' },
  { key: '/contacts', label: '联系人管理', icon: 'ContactsOutlined' },
  { key: '/calendar', label: '日程日历', icon: 'CalendarOutlined' },
  { key: '/votes', label: '投票决策', icon: 'LikeOutlined' },
   { key: '/forms', label: '表单收集', icon: 'FormOutlined' },
   { key: '/notes', label: '笔记知识库', icon: 'BookOutlined' },
  { key: '/shares', label: '文件共享', icon: 'FileOutlined' },
  { key: '/content', label: '内容编辑', icon: 'FileTextOutlined' },
  { key: '/projects', label: '项目管理', icon: 'ProjectOutlined' },
  { key: '/inventory', label: '物品管理', icon: 'AppstoreOutlined' },
  { key: '/finance', label: '财务中心', icon: 'MoneyCollectOutlined' },
  { key: '/secrets', label: '密钥保险箱', icon: 'KeyOutlined' },
  { key: '/reminders', label: '提醒事项', icon: 'BellOutlined' },
  { key: '/topology', label: '拓扑结构', icon: 'ApartmentOutlined' },
  { key: '/servers', label: '服务器管理', icon: 'CloudServerOutlined' },
  { key: '/members', label: '成员目录', icon: 'TeamOutlined' },
  { key: '/streaming', label: '直播工作室', icon: 'VideoCameraOutlined' },
];

function getMenuItems(): MenuProps['items'] {
  const sidebarItems = SIDEBAR_ITEMS;
  const items: MenuProps['items'] = sidebarItems.map((item) => ({
    key: item.key,
    label: item.label,
    icon: item.icon ? (ICON_MAP[item.icon] ?? null) : null,
  }));

  items.push(
    { type: 'divider' },
    {
      key: '/profile',
      icon: <UserOutlined />,
      label: '个人资料',
    },
    {
      key: '/settings/personalization',
      icon: <BgColorsOutlined />,
      label: '用户个性化',
    },
    {
      key: '/settings/notifications',
      icon: <BellOutlined />,
      label: '通知配置',
    },
    {
      key: '/settings/devices',
      icon: <DesktopOutlined />,
      label: '设备终端',
    },
    {
      key: '/settings/security',
      icon: <SafetyOutlined />,
      label: '安全设置',
    },
  );

  if (isAdmin()) {
    items.push({
      key: '/settings',
      icon: <SettingOutlined />,
      label: '系统设置',
      'data-menu-id': '/settings',
      children: [
        { key: '/settings/users', label: '用户账号', icon: <TeamOutlined /> },
        { key: '/settings/tags', label: '标签分类', icon: <TagOutlined /> },
        { key: '/settings/templates', label: '模板库', icon: <FormOutlined /> },
        { key: '/settings/site', label: '站点配置', icon: <GlobalOutlined /> },
        {
          key: '/settings/backups',
          label: '数据备份',
          icon: <CloudServerOutlined />,
        },
        {
          key: '/settings/transfer',
          icon: <SwapOutlined />,
          label: '数据迁转',
        },
        {
          key: '/settings/customization',
          label: '应用配置',
          icon: <SkinOutlined />,
        },
        {
          key: '/settings/system',
          label: '系统更新',
          icon: <CloudServerOutlined />,
        },
        {
          key: '/settings/storage',
          label: '存储设置',
          icon: <DatabaseOutlined />,
        },
      ],
    });
  }

  return items;
}


/** 按 DOM 顺序为所有菜单项分配飞入动画延迟（40ms 递增） */
function assignMenuAnimDelays(container: HTMLElement): void {
  const items = container.querySelectorAll(
    '.ant-menu-item, .ant-menu-submenu > .ant-menu-submenu-title'
  );
  items.forEach((el, i) => {
    const delay = i * 40 + 'ms';
    (el as HTMLElement).style.animationDelay = delay;
  });
}

/** 清除内联动画延迟（动画完成后恢复干净状态） */
function clearMenuAnimDelays(container: HTMLElement): void {
  const items = container.querySelectorAll(
    '.ant-menu-item, .ant-menu-submenu > .ant-menu-submenu-title'
  );
  items.forEach((el) => {
    (el as HTMLElement).style.animationDelay = '';
  });
}

const userMenuItems: MenuProps['items'] = [
  {
    key: 'profile',
    label: '个人资料',
  },
  {
    key: 'logout',
    label: '退出登录',
  },
];

export default function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [menuDrawerOpen, setMenuDrawerOpen] = useState(false);
  const [idlePaused, setIdlePaused] = useState(() => {
    const stored = sessionStorage.getItem('workbench_idle_paused');
    if (stored === 'true') {
      pauseIdleTimer();
      return true;
    }
    return false;
  });
  const [sidebarEntered, setSidebarEntered] = useState(false);
  const siderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setSidebarEntered(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // 侧边栏动画：按 DOM 顺序动态分配延迟（新增菜单项自动包含，无需维护 nth-child 规则）
  useEffect(() => {
    if (!sidebarEntered || !siderRef.current) return;
    const container = siderRef.current;
    assignMenuAnimDelays(container);
    // 动画完成后清理内联延迟，避免后续残留
    const cleanup = setTimeout(() => clearMenuAnimDelays(container), 1500);
    return () => clearTimeout(cleanup);
  }, [sidebarEntered, collapsed]);
  const navigate = useNavigate();
  const location = useLocation();
  const selectedKey = useMemo(() => {
    const keys = SIDEBAR_ITEMS.map((i) => i.key);
    if (keys.includes(location.pathname)) return location.pathname;
    for (const key of keys.sort((a, b) => b.length - a.length)) {
      if (location.pathname.startsWith(key + '/') || location.pathname.startsWith(key + '?')) {
        return key;
      }
    }
    return location.pathname;
  }, [location.pathname]);
  const { notifications, unreadCount, connected, markAsRead, markAllAsRead } = useWebSocket();
  const toggleIdlePause = useCallback(() => {
    setIdlePaused((prev) => {
      const next = !prev;
      if (next) {
        pauseIdleTimer();
      } else {
        resumeIdleTimer();
      }
      sessionStorage.setItem('workbench_idle_paused', String(next));
      return next;
    });
  }, []);
  const { isMobile } = useResponsive();
  const customization = useCustomization();
  const { isDark, setTheme } = useTheme();
  const { user } = useUser();
  const { isLocked, locking, lock } = useLockContext();
  useIdleTimer();
  // 状态指示：登录后启用服务级探测（C3/C4/C5）与实时通道、锁定预警（A3/E1）
  const statusIssues = useStatusProbes({ authed: user !== null, wsConnected: connected });

  // 页面缩放 + 主题（从用户偏好加载）
  const [pageZoom, setPageZoom] = useState<string>('100');
  const zoomScale = useMemo(() => Number(pageZoom) / 100, [pageZoom]);

  useEffect(() => {
    if (!user) return;
    void (async () => {
      try {
        const res = await getUserPreferences();
        if (res.code === 0 && res.data) {
          setPageZoom(res.data.page_zoom || '100');
          if (res.data.theme_mode) {
            setTheme(res.data.theme_mode as ThemeMode);
          }
        }
      } catch {
        // 忽略错误
      }
    })();
  }, [user, setTheme]);

  useEffect(() => {
    const zoomHandler = (e: CustomEvent<string>) => setPageZoom(e.detail);
    const themeHandler = (e: CustomEvent<string>) => setTheme(e.detail as ThemeMode);
    window.addEventListener('zoom-changed', zoomHandler as EventListener);
    window.addEventListener('theme-changed', themeHandler as EventListener);
    return () => {
      window.removeEventListener('zoom-changed', zoomHandler as EventListener);
      window.removeEventListener('theme-changed', themeHandler as EventListener);
    };
  }, [setTheme]);

  const [loggingOut, setLoggingOut] = useState(false);

  // 解锁溶回：LockPage 通过 sessionStorage 传信号，MainLayout 播放反向模糊进场
  const [welcoming, setWelcoming] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem('workbench_just_unlocked') === '1') {
      sessionStorage.removeItem('workbench_just_unlocked');
      setWelcoming(true);
      const timer = setTimeout(() => setWelcoming(false), 500);
      return () => clearTimeout(timer);
    }
  }, []);

  // 工作台被锁定时跳转到锁屏页
  useEffect(() => {
    if (isLocked) {
      navigate('/lock');
    }
  }, [isLocked, navigate]);

  const handleMenuOpenChange = useCallback((openKeys: string[]) => {
    if (openKeys.includes('/settings')) {
      setTimeout(() => {
        const settingsItem = document.querySelector('[data-menu-id="/settings"]');
        if (settingsItem) {
          settingsItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }, 350);
    }
  }, []);

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        transform: `scale(${zoomScale})`,
        transformOrigin: 'top left',
        width: `${100 / zoomScale}%`,
        height: `${100 / zoomScale}vh`,
        overflow: 'hidden',
      }}
    >
      <TagProvider>
        <Layout
          className={[
            locking || loggingOut ? styles.locking ?? '' : '',
            welcoming ? styles.welcoming ?? '' : '',
          ].filter(Boolean).join(' ')}
          style={{
            height: '100%',
            background: 'var(--canvas-parchment)',
            transition: 'filter 0.5s ease',
            display: 'flex',
          }}
        >
          {!isMobile && (
            <div
              className={`sider-scroll-container${sidebarEntered ? ' sidebar-entered' : ''}`}
              style={{
                height: '100%',
                position: 'absolute',
                left: 0,
                top: 0,
                width: collapsed ? 'var(--sider-collapsed-width)' : 'var(--sider-width)',
                display: 'flex',
                flexDirection: 'column',
                flexShrink: 0,
              }}
            >
            <div
              style={{
                height: 64,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                borderBottom: 'var(--sider-border)',
                gap: 2,
                flexShrink: 0,
              }}
            >
              {collapsed ? (
                customization.branding.displayMode !== 'text' &&
                customization.branding.logoCollapsed ? (
                  <img
                    src={customization.branding.logoCollapsed}
                    alt="Logo"
                    style={{ height: 28 }}
                  />
                ) : (
                  <span
                    style={{
                      fontSize: 'var(--text-heading-3-size)',
                      fontWeight: 'bold',
                      color: 'var(--ink)',
                    }}
                  >
                    {customization.app.shortName}
                  </span>
                )
              ) : (
                <>
                  {customization.branding.displayMode !== 'text' &&
                    customization.branding.logoExpanded && (
                      <img
                        src={customization.branding.logoExpanded}
                        alt="Logo"
                        style={{ height: 28 }}
                      />
                    )}
                  {customization.branding.displayMode !== 'icon' && (
                    <span
                      style={{
                        fontSize:
                          customization.branding.displayMode === 'both'
                            ? 'var(--text-body-xs-size)'
                            : 'var(--text-heading-4-size)',
                        fontWeight: 'bold',
                        color: 'var(--ink)',
                      }}
                    >
                      {customization.app.name}
                    </span>
                  )}
                </>
              )}
            </div>
            <div
              ref={siderRef}
              className="sider-menu-scroll"
              style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}
            >
              <ConfigProvider
                theme={{
                  components: {
                    Menu: {
                      itemHeight: 40,
                      itemPaddingInline: 16,
                      itemBorderRadius: 8,
                      fontSize: 14,
                      activeBarBorderWidth: collapsed ? 3 : 0,
                      itemActiveBg: 'var(--sider-menu-item-active-bg)',
                      itemSelectedBg: 'var(--sider-menu-item-active-bg)',
                      itemSelectedColor: 'var(--sider-menu-item-active-text)',
                      itemHoverBg: 'var(--sider-menu-item-hover-bg)',
                      subMenuItemBg: 'transparent',
                    },
                  },
                }}
              >
                <Sider
                  width="var(--sider-width)"
                  collapsedWidth="var(--sider-collapsed-width)"
                  collapsible
                  collapsed={collapsed}
                  onCollapse={setCollapsed}
                  trigger={null}
                  theme={isDark ? 'dark' : 'light'}
                  style={{
                    height: 'auto',
                    borderRight: 'var(--sider-border)',
                    background: 'var(--sider-bg)',
                  }}
                >
                  <Menu
                    mode="inline"
                    selectedKeys={[selectedKey]}
                    items={getMenuItems() ?? []}
                    onClick={({ key }) => navigate(key)}
                    onOpenChange={handleMenuOpenChange}
                    style={{ borderRight: 0 }}
                  />
                </Sider>
              </ConfigProvider>
            </div>
          </div>
        )}

        {isMobile && (
          <Drawer
            open={menuDrawerOpen}
            onClose={() => setMenuDrawerOpen(false)}
            placement="left"
            width={250}
            styles={{ body: { padding: 0 } }}
          >
            <div
              style={{
                height: 64,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                borderBottom: 'var(--sider-border)',
                gap: 2,
              }}
            >
              {customization.branding.displayMode !== 'text' &&
                customization.branding.logoExpanded && (
                  <img
                    src={customization.branding.logoExpanded}
                    alt="Logo"
                    style={{ height: 28 }}
                  />
                )}
              {customization.branding.displayMode !== 'icon' && (
                <span
                  style={{
                    fontSize:
                      customization.branding.displayMode === 'both'
                        ? 'var(--text-body-xs-size)'
                        : 'var(--text-heading-4-size)',
                    fontWeight: 'bold',
                  }}
                >
                  {customization.app.name}
                </span>
              )}
            </div>
            <Menu
              mode="inline"
              selectedKeys={[selectedKey]}
              items={getMenuItems() ?? []}
              onClick={({ key }) => {
                navigate(key);
                setMenuDrawerOpen(false);
              }}
              onOpenChange={handleMenuOpenChange}
              style={{ borderRight: 0 }}
            />
          </Drawer>
        )}

        <Layout
          className={`${styles.appLayout}${sidebarEntered ? ` ${styles.appEntered}` : ''}`}
          style={{
            marginLeft: isMobile
              ? 0
              : collapsed
                ? 'var(--sider-collapsed-width)'
                : 'var(--sider-width)',
            transition: 'margin-left 0.2s',
            background: 'var(--canvas-parchment)',
            height: '100%',
            overflowY: 'auto',
            flex: 1,
          }}
        >
          <Header
            style={{
              padding: isMobile ? '0 16px' : '0 24px',
              background: 'var(--header-bg)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: 'var(--header-border)',
              position: 'sticky',
              top: 0,
              zIndex: 'var(--z-sticky)',
              height: 64,
            }}
          >
            <Space>
              {isMobile && (
                <Button
                  type="text"
                  icon={<MenuOutlined />}
                  aria-label="打开导航菜单"
                  onClick={() => setMenuDrawerOpen(true)}
                  style={{ fontSize: 'var(--text-button-large-size)' }}
                />
              )}
              {!isMobile && (
                <button
                  type="button"
                  aria-label={collapsed ? '展开侧边栏' : '收起侧边栏'}
                  onClick={() => setCollapsed(!collapsed)}
                  style={{
                    fontSize: 'var(--text-button-large-size)',
                    cursor: 'pointer',
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    lineHeight: 1,
                    color: 'var(--ink)',
                  }}
                >
                  {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                </button>
              )}
            </Space>
            <Text
              strong
              style={{
                fontSize: 'var(--text-heading-4-size)',
                marginLeft: 8,
                flex: 1,
                textAlign: 'center',
              }}
            >
              {getRouteTitle(location.pathname)}
            </Text>
            <StatusIndicator issues={statusIssues} layout="inline" />
            <div className={styles.headerActions}>
              <Tooltip title="手动锁定工作台">
                <Button
                  type="text"
                  className={styles.headerIconButton ?? ''}
                  icon={
                    <LockOutlined style={{ fontSize: 'var(--header-icon-size)' }} />
                  }
                  aria-label="手动锁定工作台"
                  onClick={lock}
                />
              </Tooltip>
              <Tooltip title={idlePaused ? '自动锁定已暂停' : '空闲 5 分钟自动锁定'}>
                <Button
                  type="text"
                  className={styles.headerIconButton ?? ''}
                  icon={
                    idlePaused ? (
                      <PauseCircleOutlined style={{ fontSize: 'var(--header-icon-size)' }} />
                    ) : (
                      <ClockCircleOutlined style={{ fontSize: 'var(--header-icon-size)' }} />
                    )
                  }
                  aria-label={idlePaused ? '恢复自动锁定' : '暂停自动锁定'}
                  onClick={toggleIdlePause}
                  style={{
                    color: idlePaused ? 'var(--color-warning)' : undefined,
                  }}
                />
              </Tooltip>
              <NotificationBell
                buttonClassName={styles.headerIconButton ?? ''}
                notifications={notifications}
                unreadCount={unreadCount}
                onMarkAsRead={markAsRead}
                onMarkAllAsRead={markAllAsRead}
              />
              <Dropdown
                menu={{
                  items: userMenuItems ?? [],
                  onClick: ({ key }) => {
                    if (key === 'profile') navigate('/profile');
                    if (key === 'logout') {
                      setLoggingOut(true);
                      setTimeout(() => {
                        clearTokens();
                        navigate('/login');
                      }, 500);
                    }
                  },
                }}
                placement="bottomRight"
              >
                <div className={styles.headerUser}>
                  <Avatar
                    size="default"
                    src={user?.avatar || undefined}
                    icon={!user?.avatar ? <UserOutlined /> : undefined}
                  />
                  {!isMobile && <span>{user?.nickname || '管理员'}</span>}
                </div>
              </Dropdown>
            </div>
          </Header>
          <Content
            className={styles.content}
            style={{
              margin: isMobile ? 8 : 24,
              padding: 24,
              background: 'var(--canvas)',
              borderRadius: 'var(--rounded-sm)',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'auto',
            }}
          >
            <div
              key={location.pathname}
              className={styles.transitionWrapper}
              style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            >
              <Outlet />
            </div>
          </Content>
          <NotificationDrawer
            open={drawerOpen}
            onClose={() => setDrawerOpen(false)}
            notifications={notifications}
            onMarkAsRead={markAsRead}
            onMarkAllAsRead={markAllAsRead}
          />
          <VotePopup />
          {(locking || loggingOut) && <div className={styles.lockOverlay ?? ''} />}
          <DebugModeOverlay />
        </Layout>
      </Layout>
    </TagProvider>
    </div>
  );
}