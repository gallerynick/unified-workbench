"""Celery 异步任务配置"""

from celery import Celery

from app.core.config import get_settings
from app.tasks.backup import scheduled_backup  # noqa: F401
from app.tasks.calendar_reminder import check_calendar_reminders  # noqa: F401
from app.tasks.file_share_cleanup import cleanup_expired_shares  # noqa: F401
from app.tasks.heartbeat import beat_heartbeat  # noqa: F401
from app.tasks.reminder import check_due_reminders  # noqa: F401
from app.tasks.stream_room import (
    cleanup_temporary_rooms,  # noqa: F401
    sync_room_active_status,  # noqa: F401
)

settings = get_settings()

celery_app = Celery(
    "unified_workbench",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=[
        "app.tasks.reminder",
        "app.tasks.backup",
        "app.tasks.calendar_reminder",
        "app.tasks.stream_room",
        "app.tasks.file_share_cleanup",
        "app.tasks.heartbeat",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Shanghai",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=3600,  # 单任务最大执行时间 1 小时
    worker_max_tasks_per_child=1000,
)

# 自动发现任务
celery_app.autodiscover_tasks()

# Beat 调度配置
celery_app.conf.beat_schedule = {
    'check-due-reminders': {
        'task': 'app.tasks.reminder.check_due_reminders',
        'schedule': 10.0,
    },
    'check-calendar-reminders': {
        'task': 'app.tasks.calendar_reminder.check_calendar_reminders',
        'schedule': 10.0,
    },
    'scheduled-backup': {
        'task': 'app.tasks.backup.scheduled_backup',
        'schedule': 86400.0,
    },
    'sync-room-active-status': {
        'task': 'app.tasks.stream_room.sync_room_active_status',
        'schedule': 60.0,
    },
    'cleanup-temporary-rooms': {
        'task': 'app.tasks.stream_room.cleanup_temporary_rooms',
        'schedule': 300.0,
    },
    'cleanup-expired-shares': {
        'task': 'app.tasks.file_share_cleanup.cleanup_expired_shares',
        'schedule': 300.0,
    },
    'task-heartbeat': {
        'task': 'app.tasks.heartbeat.beat_heartbeat',
        'schedule': 60.0,
    },
}
