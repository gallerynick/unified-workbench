"""模板业务逻辑"""

from __future__ import annotations

import uuid

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.visibility import Visibility
from app.models.template import Template
from app.models.user import User, UserRole
from app.services.visibility import check_visibility as build_visibility_filter


# ── 辅助函数 ──────────────────────────────────────────────────────────


def _visibility_get_check(item: Template, user_id: uuid.UUID) -> bool:
    if item.owner_id == user_id:
        return True
    if item.visibility == Visibility.PUBLIC:
        return True
    if item.visibility == Visibility.RESTRICTED and item.restricted_users:
        if str(user_id) in item.restricted_users:
            return True
    return False


def _admin_can_manage_own_designated(
    item: Template, user_id: uuid.UUID
) -> bool:
    if item.owner_id == user_id:
        return True
    if item.visibility == Visibility.PUBLIC:
        return True
    if item.restricted_users and str(user_id) in item.restricted_users:
        return True
    return False


# ── 创建（不变）─────────────────────────────────────────────────────


async def create_template(
    db: AsyncSession,
    data: dict,
    owner_id: uuid.UUID,
) -> Template:
    """创建模板"""
    schema_data = data.get("schema") or data.get("schema_") or []
    template = Template(
        name=data["name"],
        category=data.get("category", "默认"),
        location=data.get("location", "global"),
        schema=[
            f.model_dump() if hasattr(f, "model_dump") else f
            for f in schema_data
        ],
        owner_id=owner_id,
    )
    db.add(template)
    await db.flush()
    return template


# ── 列表 ──────────────────────────────────────────────────────────────


async def list_templates(
    db: AsyncSession,
    page: int = 1,
    page_size: int = 20,
    category: str | None = None,
    search: str | None = None,
    location: str | None = None,
    user_id: uuid.UUID | None = None,
) -> tuple[list[Template], int]:
    if user_id is not None:
        visibility_cond = build_visibility_filter(Template, user_id)
        query = select(Template).where(visibility_cond)
        count_query = select(func.count()).select_from(
            select(Template).where(visibility_cond).subquery()
        )
    else:
        query = select(Template)
        count_query = select(func.count()).select_from(Template)

    if category:
        query = query.where(Template.category == category)
        if user_id is None:
            count_query = count_query.where(Template.category == category)
        else:
            count_query = select(func.count()).select_from(
                query.subquery()
            )
    if location:
        query = query.where(Template.location == location)
        if user_id is None:
            count_query = count_query.where(Template.location == location)
        else:
            count_query = select(func.count()).select_from(
                query.subquery()
            )
    if search:
        query = query.where(Template.name.ilike(f"%{search}%"))
        if user_id is None:
            count_query = count_query.where(Template.name.ilike(f"%{search}%"))
        else:
            count_query = select(func.count()).select_from(
                query.subquery()
            )

    total_result = await db.execute(count_query)
    total = total_result.scalar_one()

    query = query.order_by(Template.created_at.desc())
    query = query.offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(query)
    templates = list(result.scalars().all())

    return templates, total


# ── 获取 ──────────────────────────────────────────────────────────────


async def get_template(
    db: AsyncSession,
    template_id: uuid.UUID,
    user_id: uuid.UUID | None = None,
) -> Template:
    """获取单个模板。

    当 user_id 为 None 时不检查可见性（旧行为兼容）。
    当 user_id 提供时检查可见性。
    """
    result = await db.execute(
        select(Template).where(Template.id == template_id)
    )
    template = result.scalar_one_or_none()
    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="模板不存在"
        )
    if user_id is not None and not _visibility_get_check(template, user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="无权访问"
        )
    return template


# ── 更新 ──────────────────────────────────────────────────────────────


async def update_template(
    db: AsyncSession, template_id: uuid.UUID, data: dict, current_user: User
) -> Template:
    """更新模板，自动递增版本号。owner 或 admin（own+designated）。"""
    template = await get_template(db, template_id)

    # 权限检查：owner 或 admin（own+designated）
    if template.owner_id != current_user.id:
        if current_user.role != UserRole.ADMIN:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="仅所有者或管理员可修改",
            )
        if not _admin_can_manage_own_designated(
            template, current_user.id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="仅所有者或管理员可修改",
            )

    if "name" in data and data["name"] is not None:
        template.name = data["name"]
    if "category" in data and data["category"] is not None:
        template.category = data["category"]
    if "location" in data and data["location"] is not None:
        template.location = data["location"]
    if "schema" in data and data["schema"] is not None:
        template.schema = [
            f.model_dump() if hasattr(f, "model_dump") else f
            for f in data["schema"]
        ]
        template.version += 1

    await db.flush()
    await db.refresh(template)
    return template


# ── 删除 ──────────────────────────────────────────────────────────────


async def delete_template(
    db: AsyncSession, template_id: uuid.UUID, current_user: User
) -> None:
    """删除模板。owner 或 admin（own+designated）。"""
    template = await get_template(db, template_id)

    # 权限检查：owner 或 admin（own+designated）
    if template.owner_id != current_user.id:
        if current_user.role != UserRole.ADMIN:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="仅所有者或管理员可删除",
            )
        if not _admin_can_manage_own_designated(
            template, current_user.id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="仅所有者或管理员可删除",
            )

    await db.delete(template)
    await db.flush()


# ── 导出 JSON ─────────────────────────────────────────────────────────


async def export_template_json(
    db: AsyncSession, template_id: uuid.UUID, user_id: uuid.UUID
) -> dict:
    """导出模板为 JSON"""
    template = await get_template(db, template_id, user_id=user_id)
    return {
        "name": template.name,
        "category": template.category,
        "location": template.location,
        "schema": template.schema,
        "version": template.version,
    }


# ── 导入 JSON ─────────────────────────────────────────────────────────


async def import_template_json(
    db: AsyncSession, json_data: dict, owner_id: uuid.UUID
) -> Template:
    """从 JSON 导入模板"""
    if "name" not in json_data or "schema" not in json_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="导入数据必须包含 name 和 schema 字段",
        )

    if not isinstance(json_data["schema"], list):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="schema 必须是数组",
        )

    template = Template(
        name=json_data["name"],
        category=json_data.get("category", "默认"),
        location=json_data.get("location", "global"),
        schema=json_data["schema"],
        owner_id=owner_id,
    )
    db.add(template)
    await db.flush()
    return template
