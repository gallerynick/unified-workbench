"""应用配置模块"""

from functools import lru_cache

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """应用配置，从环境变量或 .env 文件加载"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # 应用配置
    APP_NAME: str = "一站式工作台"
    DEBUG: bool = False

    # 数据库配置
    DATABASE_URL: str = "postgresql+asyncpg://workbench:password@localhost:5432/unified_workbench"

    # Redis 配置
    REDIS_URL: str = "redis://localhost:6379/0"

    # JWT 配置
    SECRET_KEY: str = "your-jwt-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    # 二次验证（2FA）pending 令牌有效期（分钟）
    PENDING_2FA_EXPIRE_MINUTES: int = 5

    # CORS 配置
    CORS_ORIGINS: str = "http://localhost,http://localhost:3000,https://localhost"

    # 初始管理员配置
    INITIAL_ADMIN_USERNAME: str = "admin"
    INITIAL_ADMIN_PASSWORD: str = "admin123"

    # 文件分享配置
    NAS_FILES_PATH: str = "/data/files"  # 向后兼容
    FILE_STORAGE_PATH: str = "/data/files"
    RESERVED_DISK_SPACE_GB: int = 10
    MAX_SHARE_FILE_SIZE_GB: int = 1

    # 加密配置
    ENCRYPTION_MASTER_KEY: str = "7433947cd794fc1c74ca1a2063baf5defd908128356ac1f6e36b6861a1d283eb"

    # WebAuthn 配置
    WEBAUTHN_RP_ID: str = "localhost"
    WEBAUTHN_RP_NAME: str = "一站式工作台"
    WEBAUTHN_ORIGIN: str = "http://localhost,https://localhost"

    @field_validator("DATABASE_URL")
    @classmethod
    def validate_database_url(cls, v: str) -> str:
        """验证数据库 URL 使用 asyncpg 驱动"""
        if not v.startswith("postgresql+asyncpg://"):
            raise ValueError("DATABASE_URL 必须使用 postgresql+asyncpg:// 前缀")
        return v


@lru_cache
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()